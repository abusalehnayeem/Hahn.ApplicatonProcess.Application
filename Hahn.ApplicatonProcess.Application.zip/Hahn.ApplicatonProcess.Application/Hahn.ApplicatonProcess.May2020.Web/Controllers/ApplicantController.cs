﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Hahn.ApplicatonProcess.May2020.ApiModel;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Commands.CreateApplicant;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Commands.DeleteApplicant;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Commands.UpdateApplicant;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Queries;
using Hahn.ApplicatonProcess.May2020.Web.Swagger;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Filters;

namespace Hahn.ApplicatonProcess.May2020.Web.Controllers
{
    [Route("api/applicant")]
    [ApiController]
    [Consumes("application/json")]
    [Produces("application/json")]
    public class ApplicantController : ControllerBase
    {
        private readonly ILogger<ApplicantController> _logger;
        private IMediator _mediator;


        public ApplicantController(ILogger<ApplicantController> logger)
        {
            _logger = logger;
        }

        protected IMediator Mediator => _mediator ??= HttpContext.RequestServices.GetService<IMediator>();

        /// <summary>
        ///     Gets list of all applicants.
        /// </summary>
        /// <returns>The collection of all applicants.</returns>
        [HttpGet]
        public async Task<ActionResult<IList<ApplicantApiModel>>> Get()
        {
            try
            {
                var commandResult = await Mediator.Send(new GetApplicantListQuery());
                if (commandResult != null) return Ok(commandResult);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while getting all applicants.");
                return new JsonResult(new
                    {Error = new {Message = "An unhandled error occured during request processing."}});
            }

            return NotFound();
        }

        /// <summary>
        ///     Gets details of an applicant with specified id.
        /// </summary>
        /// <param name="id">Id of applicant.</param>
        /// <returns>Details of applicant.</returns>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<ApplicantApiModel>> GetById(int id)
        {
            try
            {
                var result = await Mediator.Send(new GetApplicantDetailQuery {Id = id});
                if (result != null) return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error while getting applicant with ID - {id}.");
                return new JsonResult(new
                    {Error = new {Message = "An unhandled error occured during request processing."}});
            }

            return NotFound();
        }

        /// <summary>
        ///     Saves details of new applicant.
        /// </summary>
        /// <param name="command">Applicant object.</param>
        /// <returns>Saved details of applicant.</returns>
        [HttpPost]
        [SwaggerRequestExample(typeof(CreateApplicantCommand), typeof(ApplicantPostExample))]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesDefaultResponseType]
        public async Task<ActionResult<int>> Create(CreateApplicantCommand command)
        {
            try
            {
                await Mediator.Send(command);
                return CreatedAtAction("GetById", new {id = command.Id.ToString()}, command);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while creating new applicant.");
                return new JsonResult(new
                    {Error = new {Message = "An unhandled error occured during request processing."}});
            }
        }

        /// <summary>
        ///     Updates details of applicant with specified id.
        /// </summary>
        /// <param name="command">Applicant object.</param>
        [HttpPut("{id}")]
        [SwaggerRequestExample(typeof(UpdateApplicantCommand), typeof(ApplicantPutExample))]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public async Task<ActionResult<int>> Update(UpdateApplicantCommand command)
        {
            try
            {
                await Mediator.Send(command);
                return AcceptedAtAction("GetById", new {id = command.Id}, command);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error while updating applicant with ID - {command.Id}.");
                return new JsonResult(new
                    {Error = new {Message = "An unhandled error occured during request processing."}});
            }
        }

        /// <summary>
        ///     Deletes applicant with specified if.
        /// </summary>
        /// <param name="id">Id of applicant.</param>
        /// <returns>Empty response.</returns>
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<int>> Delete(int id)
        {
            try
            {
                await Mediator.Send(new DeleteApplicantCommand {Id = id});
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error while deleting applicant with ID - {id}.");
                return new JsonResult(new
                    {Error = new {Message = "An unhandled error occured during request processing."}});
            }
        }
    }
}