﻿using Hahn.ApplicatonProcess.May2020.Application.Applicants.Commands.UpdateApplicant;
using Swashbuckle.AspNetCore.Filters;

namespace Hahn.ApplicatonProcess.May2020.Web.Swagger
{
    public class ApplicantPutExample : IExamplesProvider<UpdateApplicantCommand>
    {
        public UpdateApplicantCommand GetExamples()
        {
            return new UpdateApplicantCommand
            {
                Id = 4,
                Name = "Tobias",
                FamilyName = "Bodmann",
                Address = "Friedhofstraße 11, 93142 Maxhütte - Haidhof",
                CountryOfOrigin = "Germany",
                Age = 29,
                EMailAdress = "tobias.bodmann@gmail.com",
                Hired = true
            };
        }
    }
}