﻿using Hahn.ApplicatonProcess.May2020.Application.Applicants.Commands.CreateApplicant;
using Swashbuckle.AspNetCore.Filters;

namespace Hahn.ApplicatonProcess.May2020.Web.Swagger
{
    public class ApplicantPostExample : IExamplesProvider<CreateApplicantCommand>
    {
        public CreateApplicantCommand GetExamples()
        {
            return new CreateApplicantCommand
            {
                Name = "Tobias",
                FamilyName = "Bodmann",
                Address = "Friedhofstraße 11, 93142 Maxhütte - Haidhof",
                CountryOfOrigin = "Germany",
                Age = 29,
                EMailAdress = "tobias.bodmann@gmail.com"
            };
        }
    }
}