using Hahn.ApplicatonProcess.May2020.Application.DbSeed;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;

namespace Hahn.ApplicatonProcess.May2020.Web
{
    public class Program
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().SeedData().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
                .ConfigureLogging(config =>
                {
                    config.ClearProviders();
                    config.SetMinimumLevel(LogLevel.Debug);
                    config.AddFilter("Microsoft", LogLevel.Information);
                    config.AddFilter("System", LogLevel.Error);
                })
                .UseSerilog((hostingContext, logConfig) =>
                {
                    logConfig
                        .ReadFrom.Configuration(hostingContext.Configuration)
                        .Enrich.FromLogContext();
                })
                .ConfigureWebHostDefaults(webBuilder => { webBuilder.UseStartup<Startup>(); });
        }
    }
}