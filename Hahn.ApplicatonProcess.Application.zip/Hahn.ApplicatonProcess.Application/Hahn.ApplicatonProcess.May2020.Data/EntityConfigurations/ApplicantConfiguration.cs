﻿using Hahn.ApplicatonProcess.May2020.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Hahn.ApplicatonProcess.May2020.Data.EntityConfigurations
{
    public class ApplicantConfiguration : IEntityTypeConfiguration<Applicant>
    {
        public void Configure(EntityTypeBuilder<Applicant> builder)
        {
            builder.ToTable(@"Applicant", @"dbo");
            builder.Property(x => x.Id).HasColumnName(@"Id").HasColumnType(@"int").IsRequired()
                .ValueGeneratedOnAdd();
            builder.Property(x => x.Name).HasColumnName(@"Name").HasColumnType(@"nvarchar(100)")
                .ValueGeneratedNever().HasMaxLength(100);
            builder.Property(x => x.FamilyName).HasColumnName(@"FamilyName").HasColumnType(@"nvarchar(100)")
                .ValueGeneratedNever().HasMaxLength(100);
            builder.Property(x => x.Address).HasColumnName(@"Address").HasColumnType(@"nvarchar(300)")
                .ValueGeneratedNever().HasMaxLength(300);
            builder.Property(x => x.CountryOfOrigin).HasColumnName(@"CountryOfOrigin")
                .HasColumnType(@"nvarchar(100)").ValueGeneratedNever().HasMaxLength(100);
            builder.Property(x => x.EMailAdress).HasColumnName(@"EMailAdress").HasColumnType(@"nvarchar(100)")
                .ValueGeneratedNever().HasMaxLength(100);
            builder.Property<int?>(x => x.Age).HasColumnName(@"Age").HasColumnType(@"int").ValueGeneratedNever();
            builder.Property<bool?>(x => x.Hired).HasColumnName(@"Hired").HasColumnType(@"bit").ValueGeneratedOnAdd()
                .HasDefaultValueSql(@"0");
            builder.HasKey(@"Id");
        }
    }
}