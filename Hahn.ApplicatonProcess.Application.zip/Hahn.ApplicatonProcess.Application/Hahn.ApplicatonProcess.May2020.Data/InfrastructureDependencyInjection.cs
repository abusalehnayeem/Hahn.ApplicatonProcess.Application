﻿using Hahn.ApplicatonProcess.May2020.Application.Common.Interfaces;
using Hahn.ApplicatonProcess.May2020.Data.AppContexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Hahn.ApplicatonProcess.May2020.Data
{
    public static class InfrastructureDependencyInjection
    {
        public static IServiceCollection AddDbServiceCollection(this IServiceCollection services)
        {
            services.AddScoped<IApplicantContext>(provider => provider.GetRequiredService<ApplicantContext>())
                .AddDbContext<ApplicantContext>(options => options.UseInMemoryDatabase("ApplicantDB"));
            return services;
        }
    }
}