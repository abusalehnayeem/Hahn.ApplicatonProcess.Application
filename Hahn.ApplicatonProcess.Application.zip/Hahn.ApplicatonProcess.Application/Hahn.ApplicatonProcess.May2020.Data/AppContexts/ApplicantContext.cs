﻿using Hahn.ApplicatonProcess.May2020.Application.Common.Interfaces;
using Hahn.ApplicatonProcess.May2020.Data.EntityConfigurations;
using Hahn.ApplicatonProcess.May2020.Domain;
using Microsoft.EntityFrameworkCore;

namespace Hahn.ApplicatonProcess.May2020.Data.AppContexts
{
    public class ApplicantContext : DbContext, IApplicantContext
    {
        public ApplicantContext()
        {
        }

        public ApplicantContext(DbContextOptions<ApplicantContext> options)
            : base(options)
        {
        }

        public DbSet<Applicant> Applicants { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
            }

            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new ApplicantConfiguration());
            base.OnModelCreating(modelBuilder);
        }
    }
}