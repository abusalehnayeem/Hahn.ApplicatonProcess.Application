import { RouterConfiguration, Router } from "aurelia-router";
import { routes } from "./config/route";

export class App {
  router: Router;
  configureRouter(config: RouterConfiguration, router: Router) {
    this.router = router;
    config.title = "Client Application";
    config.map(routes);
  }
}
