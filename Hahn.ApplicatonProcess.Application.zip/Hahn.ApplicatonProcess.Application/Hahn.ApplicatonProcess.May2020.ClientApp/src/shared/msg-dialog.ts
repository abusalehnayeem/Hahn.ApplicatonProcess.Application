import { autoinject } from "aurelia-framework";
import { DialogController } from 'aurelia-dialog';
import { DialogParam } from "./dialog-param";

@autoinject()
export class MsgDialog {
  public context: DialogParam;

  constructor(public controller: DialogController) {
    this.controller.settings.lock = false;
  }

  activate(cntxt: DialogParam) {
    this.context = cntxt;
    this.controller.settings.lock = cntxt.lock;
  }
}
