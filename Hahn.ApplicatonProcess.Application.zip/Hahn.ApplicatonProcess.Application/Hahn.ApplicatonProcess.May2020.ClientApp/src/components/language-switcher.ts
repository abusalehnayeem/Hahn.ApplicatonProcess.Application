import { inject } from 'aurelia-framework';
import { I18N } from 'aurelia-i18n';
import { Shared } from '../services/shared';

@inject(I18N, Shared)
export class LanguageSwitcher {
  public languages: Array<any>;
  public selectedLanguage: string;

  constructor(private i18n: I18N, private shared: Shared) {
    this.languages = [
      { value: 'en', text: 'English (US)' },
      { value: 'de', text: 'Deutsche (German)' }
    ];
    this.selectedLanguage = 'en';
  }

  switchLanguage(): void {
    this.i18n.setLocale(this.selectedLanguage);
    this.shared.resetValidationRules();
  }
}
