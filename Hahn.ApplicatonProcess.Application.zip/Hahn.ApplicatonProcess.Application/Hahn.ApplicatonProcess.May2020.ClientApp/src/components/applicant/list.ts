import { ApplicantService } from './../../services/applicant-service';
import { Applicant } from './../../models/applicant';
import { Router } from 'aurelia-router';
import { inject } from 'aurelia-framework';

@inject(Router, ApplicantService)
export class List {
  public applicants: Array<Applicant>;

  constructor(private route: Router, private applicantService: ApplicantService) {
    this.applicants = new Array<Applicant>();
  }

  activate() {
    this.getApplicants();
  }

  getApplicants() {
    this.applicantService.getApplicants()
      .then(data => this.applicants = data);
  }

  add() {
    this.route.navigate('#/form');
  }
}
