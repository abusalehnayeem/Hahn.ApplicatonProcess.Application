import { ApplicantService } from './../../services/applicant-service';
import { Shared } from './../../services/shared';
import { Applicant } from './../../models/applicant';
import { BootstrapFormRenderer } from './../../shared/bootstrap-form-renderer';
import { inject } from 'aurelia-framework';
import { Router } from 'aurelia-router';
import {
  ValidationControllerFactory,
  ValidationController,
  Validator,
  validateTrigger
} from 'aurelia-validation';
import { I18N } from 'aurelia-i18n';
import { DOM } from 'aurelia-pal';

@inject(Router, ValidationControllerFactory, Validator, I18N, DOM, Shared, ApplicantService)
export class AppForm {
  controller: ValidationController = null;
  public appForm: Applicant = new Applicant();
  public canSave: boolean = false;
  public isError: boolean = false;
  public applicants: Array<Applicant>;

  constructor(private route: Router, private controllerFactory: ValidationControllerFactory,
    private validator: Validator, private i18n: I18N, private dom,
    private shared: Shared, private applicantService: ApplicantService) {
    this.controller = this.controllerFactory.createForCurrentScope();
    this.controller.validateTrigger = validateTrigger.changeOrBlur;
    this.controller.addRenderer(new BootstrapFormRenderer());
    this.controller.subscribe(event => this.validateWhole());
  }

  activate(params) {
    this.shared.resetValidationRules();

    if (params && params.id) {
      this.applicantService.getApplicant(params.id)
        .then(data => this.appForm = data);
    }
  }

  submit() {
    this.isError = false;
    this.controller.validate()
      .then(res => {
        if (res.valid) {
          if (Number.isInteger(this.appForm.id)) {
            this.applicantService.updateApplicant(this.appForm.id, this.appForm)
              .then(() => this.goToView(this.appForm.id));
          } else {
            this.applicantService.addApplicant(this.appForm)
              .then(data => {
                this.goToList();
              }).catch(data => {
                this.isError = true;
              }
              );
          }
        }
      });
  }

  private validateWhole() {
    this.validator.validateObject(this.appForm)
      .then(results => this.canSave = results.every(result => result.valid));
  }

  async reset() {
    this.shared.confirmDialog({ message: this.i18n.tr('applicant_layout.actions.cnf_reset'), lock: true, title: this.i18n.tr('applicant_layout.actions.btn_reset') })
      .whenClosed(response => {
        if (!response.wasCancelled) {
          this.isError = false;
          this.appForm = new Applicant();
          this.dom.getElementById('frmApplicant').reset();
          this.controller.reset();
          this.canSave = false;
        }
      });
  }

  goToView(id: number) {
    this.route.navigate('#/detail/' + id);
  }

  goToList() {
    this.route.navigate('#/');
  }
}
