export class Country {
  name: string;
}
