import { Shared } from './shared';
import { I18N } from 'aurelia-i18n';
import { HttpClient,json } from 'aurelia-fetch-client';
import { autoinject } from "aurelia-framework";

import { Applicant } from './../models/applicant';

@autoinject
export class ApplicantService {
  private baseUrl: string = 'http://localhost:62823/api/applicant';
  constructor(private httpClient: HttpClient, private i18n: I18N, private sharedCmpnt: Shared){
    this.httpClient.configure(con=>{
      con.withDefaults({
        headers:{
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      });
    });
  }

  getApplicants(): Promise<Array<Applicant>> {
    return this.httpClient.fetch(this.baseUrl + '?culture=' + this.i18n.getLocale())
      .then(response => response.json()).catch(this.handleError.bind(this));
  }
  
  getApplicant(id: number): Promise<Applicant> {
    return this.httpClient.fetch(this.baseUrl + "/" + id + '?culture=' + this.i18n.getLocale())
      .then(response => response.json()).catch(this.handleError.bind(this));
  }

  addApplicant(applicant: Applicant): Promise<Applicant> {
    return this.httpClient.fetch(this.baseUrl + '?culture=' + this.i18n.getLocale(),
      {
        method: 'POST',
        body: json(applicant)
      })
      .then(response => response.json()).catch(this.handleError.bind(this));
  }

  updateApplicant(id: number, applicant: Applicant): Promise<any> {
    return this.httpClient.fetch(this.baseUrl + "/" + id + '?culture=' + this.i18n.getLocale(),
      {
        method: 'PUT',
        body: json(applicant)
      }).catch(this.handleError.bind(this));
  }

  deleteApplicant(id: number): Promise<any> {
    return this.httpClient.fetch(this.baseUrl + "/" + id + '?culture=' + this.i18n.getLocale(), { method: 'DELETE' })
      .catch(this.handleError.bind(this));
  }

  private handleError(err) {
    console.error(err);
    this.sharedCmpnt.alertDialog({
      message: this.i18n.tr('applicant_layout.page_error'),
      lock: false,
      title: this.i18n.tr('applicant_layout.dlg_error')
    });
  }
}
