import { constants } from './../shared/constants';
import { inject } from 'aurelia-framework';
import { I18N } from 'aurelia-i18n';
import { HttpClient, json } from 'aurelia-fetch-client';
import {ValidationRules} from 'aurelia-validation';
import { Applicant } from "../models/applicant";
import { Country } from '../models/country';

import { MsgDialog } from '../shared/msg-dialog';

import { DialogService, DialogOpenPromise } from 'aurelia-dialog';
import { DialogParam } from '../shared/dialog-param';

let http = new HttpClient();
@inject(I18N, DialogService)
export class Shared {

  constructor(private i18n: I18N, private dialogService: DialogService) {
  }

  public resetValidationRules() {
    ValidationRules.customRule('validCountry', (value) => {
     // if (!value || value.length === 0) return Promise.resolve(true);
      return http.fetch(constants.countryOfOriginCheckUrl + 'name/' + value + '?fullText=true')
        .then((response) => 200 === response.status);
    }, this.i18n.tr('applicant_layout.validations.valid'));

    let required = this.i18n.tr('applicant_layout.validations.required');
    ValidationRules
      .ensure((a: Applicant) => a.name).displayName(this.i18n.tr('applicant_layout.fld_name')).required().withMessage(required).minLength(5).withMessage(this.i18n.tr('applicant_layout.validations.minLength5'))
      .ensure((a: Applicant) => a.familyName).displayName(this.i18n.tr('applicant_layout.fld_family_name')).required().withMessage(required).minLength(5).withMessage(this.i18n.tr('applicant_layout.validations.minLength5'))
      .ensure((a: Applicant) => a.address).displayName(this.i18n.tr('applicant_layout.fld_address')).required().withMessage(required).minLength(10).withMessage(this.i18n.tr('applicant_layout.validations.minLength10'))
      .ensure((a: Applicant) => a.countryOfOrigin).displayName(this.i18n.tr('applicant_layout.fld_country_of_origin')).required().withMessage(required).then().satisfiesRule('validCountry')
      .ensure((a: Applicant) => a.eMailAdress).displayName(this.i18n.tr('applicant_layout.fld_email')).required().withMessage(required).matches(new RegExp(/^[A-Z0-9_'%=+!`#~$*?^{}&|-]+([\.][A-Z0-9_'%=+!`#~$*?^{}&|-]+)*@[A-Z0-9-]+(\.[A-Z0-9-]+)+$/i)).withMessage(this.i18n.tr('applicant_layout.validations.valid'))
      .ensure((a: Applicant) => a.age).displayName(this.i18n.tr('applicant_layout.fld_age')).required().withMessage(required).then().range(20, 60).withMessage(this.i18n.tr('applicant_layout.validations.range20_60'))
      .on(Applicant);
  }

  confirmDialog(context: DialogParam): DialogOpenPromise<any> {
    context.lock = true;
    return this.dialogService.open({
      viewModel: MsgDialog, model: context, lock: true
    });
  }

  alertDialog(context: DialogParam): DialogOpenPromise<any> {
    context.lock = false;
    return this.dialogService.open({
      viewModel: MsgDialog, model: context, lock: false
    });
  }
}
