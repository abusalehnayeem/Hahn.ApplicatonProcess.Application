﻿using Hahn.ApplicatonProcess.May2020.Application.Common.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Hahn.ApplicatonProcess.May2020.Application.DbSeed
{
    public static class HostExtensions
    {
        public static IHost SeedData(this IHost host)
        {
            using (var scope = host.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                var context = services.GetService(typeof(IApplicantContext)) as IApplicantContext;

                new DbInitializer(context).PopulateInitialData();
            }

            return host;
        }
    }
}