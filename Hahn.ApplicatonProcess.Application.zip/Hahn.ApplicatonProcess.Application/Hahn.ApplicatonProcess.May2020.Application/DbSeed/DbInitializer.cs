﻿using System.Collections.Generic;
using Hahn.ApplicatonProcess.May2020.Application.Common.Interfaces;
using Hahn.ApplicatonProcess.May2020.Domain;

namespace Hahn.ApplicatonProcess.May2020.Application.DbSeed
{
    public class DbInitializer
    {
        private readonly IApplicantContext _applicantContext;

        public DbInitializer(IApplicantContext applicantContext)
        {
            _applicantContext = applicantContext;
        }

        public void PopulateInitialData()
        {
            var applicants = new List<Applicant>
            {
                new Applicant
                {
                    Id = 1,
                    Name = "Abusaleh",
                    FamilyName = "Nayeem",
                    Address = "Dhaka, Bangladesh",
                    Age = 35,
                    CountryOfOrigin = "Bangladesh",
                    EMailAdress = "nayeemmbstu@gmail.com",
                    Hired = true
                },
                new Applicant
                {
                    Id = 2,
                    Name = "Another Name",
                    FamilyName = "Another Name",
                    Address = "Dhaka, Bangladesh",
                    Age = 32,
                    CountryOfOrigin = "Bangladesh",
                    EMailAdress = "test@test.com",
                    Hired = false
                },
                new Applicant
                {
                    Id = 3,
                    Name = "John",
                    FamilyName = "Bush",
                    Address = "Delhi, India",
                    Age = 40,
                    CountryOfOrigin = "India",
                    EMailAdress = "b.hough@outlook.com",
                    Hired = false
                }
            };

            _applicantContext.Applicants.AddRange(applicants);

            _applicantContext.SaveChangesAsync();
        }
    }
}