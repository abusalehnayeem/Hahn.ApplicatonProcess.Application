﻿using MediatR;

namespace Hahn.ApplicatonProcess.May2020.Application.Applicants.Commands.DeleteApplicant
{
    public class DeleteApplicantCommand : IRequest<int>
    {
        public int Id { get; set; }
    }
}