﻿using System.Collections.Generic;
using Hahn.ApplicatonProcess.May2020.ApiModel;
using MediatR;

namespace Hahn.ApplicatonProcess.May2020.Application.Applicants.Queries
{
    public class GetApplicantListQuery : IRequest<List<ApplicantApiModel>>
    {
    }
}