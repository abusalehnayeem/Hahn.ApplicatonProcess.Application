﻿using Hahn.ApplicatonProcess.May2020.ApiModel;
using MediatR;

namespace Hahn.ApplicatonProcess.May2020.Application.Applicants.Queries
{
    public class GetApplicantDetailQuery : IRequest<ApplicantApiModel>
    {
        public int Id { get; set; }
    }
}