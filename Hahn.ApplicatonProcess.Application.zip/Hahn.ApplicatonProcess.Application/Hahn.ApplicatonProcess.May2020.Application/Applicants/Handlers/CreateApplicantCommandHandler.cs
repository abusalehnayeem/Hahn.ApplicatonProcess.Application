﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Commands.CreateApplicant;
using Hahn.ApplicatonProcess.May2020.Application.Common.Interfaces;
using Hahn.ApplicatonProcess.May2020.Domain;
using MediatR;

namespace Hahn.ApplicatonProcess.May2020.Application.Applicants.Handlers
{
    public class CreateApplicantCommandHandler : BaseHandler, IRequestHandler<CreateApplicantCommand, int>
    {
        public CreateApplicantCommandHandler(IApplicantContext context, IMapper mapper) : base(context, mapper)
        {
        }

        public async Task<int> Handle(CreateApplicantCommand request, CancellationToken cancellationToken = default)
        {
            var entity = Mapper.Map<Applicant>(request);
            var maxId = Context.Applicants.Max(a => a.Id);
            entity.Id = maxId + 1;
            Context.Applicants.Add(entity);
            await Context.SaveChangesAsync(cancellationToken);
            return entity.Id;
        }
    }
}