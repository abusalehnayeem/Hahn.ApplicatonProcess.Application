﻿using AutoMapper;
using Hahn.ApplicatonProcess.May2020.Application.Common.Interfaces;

namespace Hahn.ApplicatonProcess.May2020.Application.Applicants.Handlers
{
    public abstract class BaseHandler
    {
        protected readonly IApplicantContext Context;
        protected readonly IMapper Mapper;

        protected BaseHandler(IApplicantContext context, IMapper mapper)
        {
            (Context, Mapper) = (context, mapper);
        }
    }
}