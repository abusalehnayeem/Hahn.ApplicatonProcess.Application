﻿using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Commands.UpdateApplicant;
using Hahn.ApplicatonProcess.May2020.Application.Common.Exceptions;
using Hahn.ApplicatonProcess.May2020.Application.Common.Interfaces;
using Hahn.ApplicatonProcess.May2020.Domain;
using MediatR;

namespace Hahn.ApplicatonProcess.May2020.Application.Applicants.Handlers
{
    public class UpdateApplicantCommandHandler : BaseHandler, IRequestHandler<UpdateApplicantCommand, int>
    {
        public UpdateApplicantCommandHandler(IApplicantContext context, IMapper mapper) : base(context, mapper)
        {
        }

        public async Task<int> Handle(UpdateApplicantCommand request, CancellationToken cancellationToken = default)
        {
            if (request == null) throw new ApplicantBadRequestException("request parameter is missing!");

            var entity = await Context.Applicants.FindAsync(request.Id);
            if (entity == null) throw new ApplicantNotFoundException(nameof(Applicant), request.Id);

            entity = Mapper.Map<Applicant>(request);
            await Context.SaveChangesAsync(cancellationToken);
            return entity.Id;
        }
    }
}