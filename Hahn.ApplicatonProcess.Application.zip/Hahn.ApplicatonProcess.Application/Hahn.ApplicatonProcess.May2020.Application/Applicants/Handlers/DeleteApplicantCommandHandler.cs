﻿using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Commands.DeleteApplicant;
using Hahn.ApplicatonProcess.May2020.Application.Common.Exceptions;
using Hahn.ApplicatonProcess.May2020.Application.Common.Interfaces;
using Hahn.ApplicatonProcess.May2020.Domain;
using MediatR;

namespace Hahn.ApplicatonProcess.May2020.Application.Applicants.Handlers
{
    public class DeleteApplicantCommandHandler : BaseHandler, IRequestHandler<DeleteApplicantCommand, int>
    {
        public DeleteApplicantCommandHandler(IApplicantContext context, IMapper mapper) : base(context, mapper)
        {
        }

        public async Task<int> Handle(DeleteApplicantCommand request, CancellationToken cancellationToken = default)
        {
            if (request == null) throw new ApplicantBadRequestException("request parameter is missing!");

            var entity = await Context.Applicants.FindAsync(request.Id);
            if (entity == null) throw new ApplicantNotFoundException(nameof(Applicant), request.Id);

            entity = Mapper.Map<Applicant>(request);
            Context.Applicants.Remove(entity);
            await Context.SaveChangesAsync(cancellationToken);
            return entity.Id;
        }
    }
}