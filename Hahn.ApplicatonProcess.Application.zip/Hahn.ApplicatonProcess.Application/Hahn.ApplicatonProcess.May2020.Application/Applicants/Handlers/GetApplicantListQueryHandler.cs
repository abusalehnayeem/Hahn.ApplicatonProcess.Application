﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Hahn.ApplicatonProcess.May2020.ApiModel;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Queries;
using Hahn.ApplicatonProcess.May2020.Application.Common.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Hahn.ApplicatonProcess.May2020.Application.Applicants.Handlers
{
    public class GetApplicantListQueryHandler : BaseHandler,
        IRequestHandler<GetApplicantListQuery, List<ApplicantApiModel>>
    {
        public GetApplicantListQueryHandler(IApplicantContext context, IMapper mapper) : base(context, mapper)
        {
        }

        public async Task<List<ApplicantApiModel>> Handle(GetApplicantListQuery request,
            CancellationToken cancellationToken = default)
        {
            var result = new List<ApplicantApiModel>();
            var applicantList = await Context.Applicants.ToListAsync(cancellationToken);
            if (applicantList != null) result = Mapper.Map<List<ApplicantApiModel>>(applicantList);
            return result;
        }
    }
}