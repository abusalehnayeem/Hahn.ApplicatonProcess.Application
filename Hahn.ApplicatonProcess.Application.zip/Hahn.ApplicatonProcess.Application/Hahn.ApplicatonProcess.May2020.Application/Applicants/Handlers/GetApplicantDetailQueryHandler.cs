﻿using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Hahn.ApplicatonProcess.May2020.ApiModel;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Queries;
using Hahn.ApplicatonProcess.May2020.Application.Common.Exceptions;
using Hahn.ApplicatonProcess.May2020.Application.Common.Interfaces;
using Hahn.ApplicatonProcess.May2020.Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Hahn.ApplicatonProcess.May2020.Application.Applicants.Handlers
{
    public class GetApplicantDetailQueryHandler : BaseHandler,
        IRequestHandler<GetApplicantDetailQuery, ApplicantApiModel>
    {
        public GetApplicantDetailQueryHandler(IApplicantContext context, IMapper mapper) : base(context, mapper)
        {
        }

        public async Task<ApplicantApiModel> Handle(GetApplicantDetailQuery request,
            CancellationToken cancellationToken = default)
        {
            var applicant =
                await Context.Applicants
                    .FirstOrDefaultAsync(u => u.Id == request.Id, cancellationToken);

            var result = applicant != null
                ? Mapper.Map<ApplicantApiModel>(applicant)
                : throw new ApplicantNotFoundException(nameof(Applicant), request.Id);
            return result;
        }
    }
}