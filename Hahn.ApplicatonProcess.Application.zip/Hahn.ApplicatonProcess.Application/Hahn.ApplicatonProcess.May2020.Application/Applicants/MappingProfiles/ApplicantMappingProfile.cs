﻿using AutoMapper;
using Hahn.ApplicatonProcess.May2020.ApiModel;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Commands.CreateApplicant;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Commands.DeleteApplicant;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Commands.UpdateApplicant;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Queries;
using Hahn.ApplicatonProcess.May2020.Domain;

namespace Hahn.ApplicatonProcess.May2020.Application.Applicants.MappingProfiles
{
    public class ApplicantMappingProfile : Profile
    {
        public ApplicantMappingProfile()
        {
            //Request Model Mapping
            CreateMap<Applicant, ApplicantApiModel>().ReverseMap();
            //Create Command Mapping
            CreateMap<Applicant, CreateApplicantCommand>().ReverseMap();
            CreateMap<Applicant, UpdateApplicantCommand>().ReverseMap();
            CreateMap<Applicant, DeleteApplicantCommand>().ReverseMap();

            //Response Model Mapping
            CreateMap<Applicant, GetApplicantDetailQuery>().ReverseMap();
            CreateMap<Applicant, GetApplicantListQuery>().ReverseMap();
        }
    }
}