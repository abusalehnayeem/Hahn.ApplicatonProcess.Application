﻿using System.Net.Http;
using FluentValidation;
using FluentValidation.Validators;
using Hahn.ApplicatonProcess.May2020.Application.Applicants.Commands.CreateApplicant;

namespace Hahn.ApplicatonProcess.May2020.Application.Applicants.Validators
{
    public class CreateApplicantCommandValidator : AbstractValidator<CreateApplicantCommand>
    {
        public CreateApplicantCommandValidator(IHttpClientFactory httpClientFactory)
        {
            RuleFor(x => x.Name)
                .NotEmpty()
                .MinimumLength(5);

            RuleFor(x => x.FamilyName)
                .NotEmpty()
                .MinimumLength(5);


            RuleFor(x => x.Age)
                .InclusiveBetween(20, 60);

            RuleFor(x => x.Address)
                .NotEmpty()
                .MinimumLength(10);

            RuleFor(x => x.EMailAdress)
                .NotEmpty()
                .EmailAddress(EmailValidationMode.AspNetCoreCompatible);

            RuleFor(x => x.CountryOfOrigin)
                .NotEmpty()
                .SetValidator(new CountryValidator(httpClientFactory));
        }
    }
}