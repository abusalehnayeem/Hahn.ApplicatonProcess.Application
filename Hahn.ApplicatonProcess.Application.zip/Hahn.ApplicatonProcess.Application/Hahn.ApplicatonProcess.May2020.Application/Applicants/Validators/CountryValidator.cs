﻿using System.Net.Http;
using FluentValidation.Validators;

namespace Hahn.ApplicatonProcess.May2020.Application.Applicants.Validators
{
    public class CountryValidator : PropertyValidator
    {
        //private readonly IHttpClientFactory httpClientFactory;
        private readonly HttpClient _client;

        public CountryValidator(IHttpClientFactory httpClientFactory)
            : base("{PropertyName} is not a valid country")
        {
            _client = httpClientFactory.CreateClient(nameof(CountryValidator));
        }

        protected override bool IsValid(PropertyValidatorContext context)
        {
            var countryName = context.PropertyValue as string;

            if (string.IsNullOrEmpty(countryName)) return false;

            var response = _client.GetAsync($"{countryName}?fullText=true").GetAwaiter().GetResult();
            return response.IsSuccessStatusCode ? true : false;
        }
    }
}