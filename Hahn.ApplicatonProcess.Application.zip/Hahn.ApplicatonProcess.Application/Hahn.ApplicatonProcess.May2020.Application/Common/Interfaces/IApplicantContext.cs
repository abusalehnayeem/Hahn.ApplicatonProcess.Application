﻿using System.Threading;
using System.Threading.Tasks;
using Hahn.ApplicatonProcess.May2020.Domain;
using Microsoft.EntityFrameworkCore;

namespace Hahn.ApplicatonProcess.May2020.Application.Common.Interfaces
{
    public interface IApplicantContext
    {
        DbSet<Applicant> Applicants { get; set; }
        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    }
}