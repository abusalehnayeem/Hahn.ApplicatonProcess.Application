﻿using System;

namespace Hahn.ApplicatonProcess.May2020.Application.Common.Exceptions
{
    public class ApplicantBadRequestException : Exception
    {
        public ApplicantBadRequestException(string message)
            : base(message)
        {
        }
    }
}