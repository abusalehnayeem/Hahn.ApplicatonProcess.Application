﻿using System;
using System.Collections.Generic;
using System.Linq;
using FluentValidation.Results;

namespace Hahn.ApplicatonProcess.May2020.Application.Common.Exceptions
{
    public class ApplicantValidationException : Exception
    {
        public ApplicantValidationException()
            : base("One or more validation failures have occurred.")
        {
            Errors = new Dictionary<string, string[]>();
        }

        public ApplicantValidationException(IEnumerable<ValidationFailure> failures)
            : this()
        {
            var failureGroups = failures
                .GroupBy(e => e.PropertyName, e => e.ErrorMessage);

            foreach (var failureGroup in failureGroups)
            {
                var propertyName = failureGroup.Key;
                var propertyFailures = failureGroup.ToArray();

                Errors.Add(propertyName, propertyFailures);
            }
        }

        public IDictionary<string, string[]> Errors { get; }
    }
}