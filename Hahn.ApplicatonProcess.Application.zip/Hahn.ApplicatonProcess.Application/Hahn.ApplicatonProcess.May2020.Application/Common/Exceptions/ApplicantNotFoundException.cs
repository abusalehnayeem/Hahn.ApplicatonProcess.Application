﻿using System;

namespace Hahn.ApplicatonProcess.May2020.Application.Common.Exceptions
{
    public class ApplicantNotFoundException : Exception
    {
        public ApplicantNotFoundException(string name, object key)
            : base($"Entity \"{name}\" ({key}) was not found.")
        {
        }
    }
}