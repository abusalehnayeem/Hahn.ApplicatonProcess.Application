﻿using System;

namespace Hahn.ApplicatonProcess.May2020.Application.Common.Exceptions
{
    public class ApplicantDeleteFailureException : Exception
    {
        public ApplicantDeleteFailureException(string name, object key, string message)
            : base($"Deletion of entity \"{name}\" ({key}) failed. {message}")
        {
        }
    }
}